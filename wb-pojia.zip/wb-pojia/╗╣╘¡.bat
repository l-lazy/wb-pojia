@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

set "NODE="
if exist "D:\softwear\node\node.exe" set "NODE=D:\softwear\node\node.exe"
if not defined NODE if exist "%USERPROFILE%\.workbuddy\binaries\node\versions\22.22.2-6\node.exe" set "NODE=%USERPROFILE%\.workbuddy\binaries\node\versions\22.22.2-6\node.exe"
if not defined NODE (
  for /f "delims=" %%i in ('where node 2^>nul') do if not defined NODE set "NODE=%%i"
)
if not defined NODE (
  echo [错误] 未找到 node.exe
  pause
  exit /b 1
)

echo ============================================
echo   wb-pojia 破甲插件 —— 还原
echo ============================================
echo.
echo 即将从 backup\ 目录还原所有被修改的文件，
echo 并剥离已注入的破甲覆盖层。
echo.
set /p ANS=确认还原？(Y/N):
if /i not "%ANS%"=="Y" (
  echo 已取消。
  pause
  exit /b 0
)

"%NODE%" "%~dp0lib\engine.mjs" revert
echo.
echo 还原完成。请重新打开 WorkBuddy 恢复原版。
echo.
pause
