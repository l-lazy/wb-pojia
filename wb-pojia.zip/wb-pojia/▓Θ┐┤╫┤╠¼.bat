@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

set "NODE="
if exist "D:\softwear\node\node.exe" set "NODE=D:\softwear\node\node.exe"
if not defined NODE if exist "%USERPROFILE%\.workbuddy\binaries\node\versions\22.22.2-6\node.exe" set "NODE=%USERPROFILE%\.workbuddy\binaries\node\versions\22.22.2-6\node.exe"
if not defined NODE (
  for /f "delims=" %%i in ('where node 2^>nul') do if not defined NODE set "NODE=%%i"
)
if not defined NODE (
  echo [错误] 未找到 node.exe
  pause
  exit /b 1
)

echo ============================================
echo   wb-pojia 破甲插件 —— 查看状态
echo ============================================
echo.
"%NODE%" "%~dp0lib\engine.mjs" status
echo.
echo 如需逐文件定位失败原因，请运行 检测.bat 或：
echo   "%NODE%" "%~dp0lib\engine.mjs" diagnose
echo.
pause
