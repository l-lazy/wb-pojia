@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

set "NODE="
if exist "D:\softwear\node\node.exe" set "NODE=D:\softwear\node\node.exe"
if not defined NODE if exist "%USERPROFILE%\.workbuddy\binaries\node\versions\22.22.2-6\node.exe" set "NODE=%USERPROFILE%\.workbuddy\binaries\node\versions\22.22.2-6\node.exe"
if not defined NODE (
  for /f "delims=" %%i in ('where node 2^>nul') do if not defined NODE set "NODE=%%i"
)
if not defined NODE (
  echo [错误] 未找到 node.exe
  pause
  exit /b 1
)

echo ============================================
echo   wb-pojia 破甲插件 —— 停止
echo ============================================
echo.
echo 停止 = 撤销 settings.json 里的 hooks 持久注入，
echo 使 WorkBuddy 每次会话不再自动调用本插件。
echo （已注入的文本文件保留，如需彻底清除请再运行 还原.bat）
echo.
set /p ANS=确认停止？(Y/N):
if /i not "%ANS%"=="Y" (
  echo 已取消。
  pause
  exit /b 0
)

"%NODE%" "%~dp0lib\engine.mjs" stop
echo.
pause
