@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

REM 查找 node.exe
set "NODE="
if exist "D:\softwear\node\node.exe" set "NODE=D:\softwear\node\node.exe"
if not defined NODE if exist "%USERPROFILE%\.workbuddy\binaries\node\versions\22.22.2-6\node.exe" set "NODE=%USERPROFILE%\.workbuddy\binaries\node\versions\22.22.2-6\node.exe"
if not defined NODE (
  for /f "delims=" %%i in ('where node 2^>nul') do if not defined NODE set "NODE=%%i"
)

if not defined NODE (
  echo [错误] 未找到 node.exe
  echo   请安装 Node.js 或把 node.exe 放到 PATH 里。
  pause
  exit /b 1
)

REM 支持 --hook 静默模式（由 settings.json hooks 调用）
set "MODE=apply"
for %%a in (%*) do (
  if "%%a"=="--hook" set "MODE=hook"
  if "%%a"=="--status" set "MODE=status"
  if "%%a"=="--diagnose" set "MODE=diagnose"
)

if "%MODE%"=="hook" (
  REM hooks 静默校验：只注入，不弹窗
  "%NODE%" "%~dp0lib\engine.mjs" apply >nul 2>&1
  exit /b 0
)

echo ============================================
echo   wb-pojia 破甲插件 —— 一键启动
echo ============================================
echo.

"%NODE%" "%~dp0lib\engine.mjs" apply

echo.
echo 注入完成。请完全退出并重新打开 WorkBuddy 使其生效。
echo 验证方式：在对话框单独发送  CR  应回复：
echo   CR已生效 · WorkBuddy v1.0.50 当前专业版
echo.
pause
