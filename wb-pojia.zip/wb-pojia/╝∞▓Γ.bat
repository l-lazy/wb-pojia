@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"

set "NODE="
if exist "D:\softwear\node\node.exe" set "NODE=D:\softwear\node\node.exe"
if not defined NODE if exist "%USERPROFILE%\.workbuddy\binaries\node\versions\22.22.2-6\node.exe" set "NODE=%USERPROFILE%\.workbuddy\binaries\node\versions\22.22.2-6\node.exe"
if not defined NODE (
  for /f "delims=" %%i in ('where node 2^>nul') do if not defined NODE set "NODE=%%i"
)
if not defined NODE (
  echo [错误] 未找到 node.exe
  pause
  exit /b 1
)

:menu
cls
echo ================================================
echo   wb-pojia 破甲插件 —— 检测 / 修复
echo ================================================
echo.
echo 本工具逐文件诊断破甲状态，定位是哪一步、因为
echo 什么原因没有破甲，并可在此直接操作修复。
echo.
echo   [1] 运行完整诊断（逐文件列出状态与原因）
echo   [2] 重新注入全部通道（修复所有失败项）
echo   [3] 打开破甲契约 payload 模板（手动编辑内容）
echo   [4] 打开 SOUL 身份模板（手动编辑）
echo   [5] 打开 WorkBuddy 数据目录（手动检查目标文件）
echo   [6] 查看当前状态摘要
echo   [0] 退出
echo.
set /p CHOICE=请输入选项数字并按回车: 

if "%CHOICE%"=="1" goto diag
if "%CHOICE%"=="2" goto apply
if "%CHOICE%"=="3" goto editcontract
if "%CHOICE%"=="4" goto editsoul
if "%CHOICE%"=="5" goto openhome
if "%CHOICE%"=="6" goto status
if "%CHOICE%"=="0" exit /b 0
goto menu

:diag
cls
echo === 完整诊断（逐文件） ===
echo.
"%NODE%" "%~dp0lib\engine.mjs" diagnose
echo.
echo ------------------------------------------------
echo 阅读提示：
echo   ✓ applied   = 已破甲，正常
echo   ✗ pending   = 未破甲，需重新注入
echo   · skip/missing = 空文件/无目标，可忽略
echo.
echo 若关键通道(主 system prompt)显示 pending，说明破甲
echo 失效；回到菜单选 [2] 重新注入即可。
echo.
pause
goto menu

:apply
cls
echo === 重新注入全部通道 ===
echo.
"%NODE%" "%~dp0lib\engine.mjs" apply
echo.
pause
goto menu

:editcontract
cls
echo === 破甲契约模板 ===
echo 文件: payload\contract.md
echo 这是注入到主 system prompt / CODEBUDDY.md / rules 的
echo 完整破甲契约文本，可直接编辑后重新注入。
echo.
echo 即将用记事本打开...
start notepad "%~dp0payload\contract.md"
echo.
echo 编辑保存后，回到菜单选 [2] 重新注入。
pause
goto menu

:editsoul
cls
echo === SOUL 身份模板 ===
echo 文件: payload\soul.md
echo 这是注入到 SOUL.md 的身份契约文本。
echo.
start notepad "%~dp0payload\soul.md"
echo.
echo 编辑保存后，回到菜单选 [2] 重新注入。
pause
goto menu

:openhome
cls
echo === 打开 WorkBuddy 数据目录 ===
set "HOME=%USERPROFILE%\.workbuddy"
if defined WORKBUDDY_HOME set "HOME=%WORKBUDDY_HOME%"
echo 目录: %HOME%
explorer "%HOME%"
echo.
echo 关键注入目标：
echo   cache\acc-product-config-v3-*.json  ← 主 system prompt(最关键)
echo   CODEBUDDY.md
echo   rules\*.mdc
echo   plugins\cache\...\prompt.tpl
echo   memory\*_memory.md
echo   user-*-personal\SOUL.md
echo   skills\cr-reverse-skill\SKILL.md
echo   settings.json  (hooks)
pause
goto menu

:status
cls
echo === 当前状态摘要 ===
echo.
"%NODE%" "%~dp0lib\engine.mjs" status
echo.
pause
goto menu
